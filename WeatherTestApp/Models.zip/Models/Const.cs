﻿using System;

namespace WeatherTestApp
{
	public class Const
	{
		
	}
}

