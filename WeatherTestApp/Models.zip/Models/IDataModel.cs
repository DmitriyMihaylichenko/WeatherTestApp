﻿using System;

using System.Collections.Generic;

namespace WeatherTestApp
{
	public interface IDataModel<T>
	{
		string[] getAllSections();
		string getSectionByIndex(int index);
		List<T> getItemsInSectionByName(string name);
	}
}

