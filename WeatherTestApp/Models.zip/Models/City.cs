﻿using System;

namespace WeatherTestApp
{
	public class City
	{
		//{"_id":707860,"name":"Hurzuf","country":"UA","coord":{"lon":34.283333,"lat":44.549999}}

		public struct CityCoord {
			float Lon;
			float Lat;
		}

		public int Id { get; set; }
		public string Name { get; set; }
		public string Country { get; set; }
		public CityCoord Coord { get; set; }

		public City ()
		{
		}
	}
}

