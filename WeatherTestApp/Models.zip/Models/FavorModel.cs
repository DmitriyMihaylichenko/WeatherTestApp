﻿using System;

namespace WeatherTestApp
{
	public class FavorModel
	{
		public FavorModel ()
		{
		}
	}
}

