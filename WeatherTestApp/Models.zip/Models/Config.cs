﻿using System;

namespace WeatherTestApp
{
	public class Config
	{
		public const string cityListFile = "city.list.json";
	}
}

