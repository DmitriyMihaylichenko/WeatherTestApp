﻿using System;
using System.IO;
using System.Collections.Generic;

namespace WeatherTestApp
{
	public class CitiesModel
	{
		public List<City> citiesList;

		public CitiesModel ()
		{
		}

		// Parse items from JSON
		public List<City> parseJSON(string fileName) {
			citiesList = new List<City> ();

			string text = File.ReadAllText(fileName);

			var json = JsonValue.Parse(text);
			var data = json["applications"];

			foreach (JsonValue sectionEntry in data) {
				string sectionName = sectionEntry["sectionName"];

				if(!resDict.ContainsKey(sectionName)){
					resDict.Add (sectionName, new List<AppInfo>());
				}

				List<AppInfo> appsListInfo = new List<AppInfo> ();

				foreach(JsonValue sectionContent in sectionEntry["sectionContent"]) {
					string appName = sectionContent["appName"];
					string appIcon = sectionContent["appIcon"];
					string appContr = sectionContent["appContr"];

					appsListInfo.Add (new AppInfo(){ Name = appName,
						Icon = appIcon,
						Contr = appContr });
				}

				resDict[sectionName] = appsListInfo;
			}

			return resDict;
		}

		public bool initForIOS(){

		}
	}
}

